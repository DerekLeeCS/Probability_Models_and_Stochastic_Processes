function trials = genQ1A( maxVal, numRolls, numTrials )

    trials = unidrnd( maxVal, numRolls, numTrials );
    
end