function percent = pmfTroll( hp )

    percent = 0.25 * ( hp>0 ) * ( hp<=4 );

end