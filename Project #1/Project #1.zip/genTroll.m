function trials = genTroll( numTrials )

    trials = unidrnd( 4, 1, numTrials );
    
end